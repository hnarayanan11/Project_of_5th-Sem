/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
/**
 *
 * @author Hari
 */
@WebServlet(urlPatterns = {"/telebill"})
public class telebill extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        int tele=Integer.parseInt(request.getParameter("tele"));
        try{
                Class.forName("com.jdbc.mysql.Driver");
                Connection con=DriverManager.getConnection("Jdbc:mysql:","root","root");
                Statement st=con.createStatement();
                ResultSet rs=st.executeQuery("select bill from telephone");
                out.println("<html><body><form action=\"bank.java\" method=\"post\">");
                if(rs.getInt("tele")==tele){while(rs.next()){
                out.println("<h2 align=\"center\">"+rs.getString("bill")+"</h2>");
                out.println("<input type=\"submit\" value=\"Pay_Bill\"></form></body></html>");
                }}
            }catch(Exception e){out.println(e);}
        }
}