/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
/**
 *
 * @author Hari
 */
@WebServlet(urlPatterns = {"/bank"})
public class bank extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();
        String digi=request.getParameter("digi");
        int cvv=Integer.parseInt(request.getParameter("cvv"));
        int balance;
        try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("Jdbc:mysql:","root","root");
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery("select bal,cvv from banmk where digi='"+digi+"'");
        if((cvv==rs.getInt("cvv"))){
        balance=rs.getInt("bal");
        balance-=500;
        st.executeUpdate("update table bank bal='"+balance+"' where digi=digi");
        }        else{
            response.sendRedirect("index.jsp");
            out.println("Sorry...! Transaction Failed, Since insiffient balance or session time out or anything");
        }
        }catch(Exception e){out.println(e);}
    }   
    }